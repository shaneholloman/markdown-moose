# Test Images in Workspace

This file is in a workspace with a .moose config file that should take precedence over VSCode settings.

![GitHub Logo](https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png)

The images should be downloaded to ./workspace-images/ as specified in the workspace's .moose config.
